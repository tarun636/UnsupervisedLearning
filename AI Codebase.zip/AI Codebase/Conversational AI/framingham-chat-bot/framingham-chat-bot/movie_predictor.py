import numpy as np
from lightfm.datasets import fetch_movielens
import pickle
from lightfm import LightFM
from lightfm.evaluation import precision_at_k
import json

MODEL_PATH = 'static/model/model_movielens.pkl'
data = fetch_movielens(min_rating=5.0, genre_features=True)

# print(data.keys())

# print(data)


def sample_recommendation(model, data, user_ids):

    n_users, n_items = data['train'].shape

    for user_id in user_ids:
        known_positives = data['item_labels'][
            data['train'].tocsr()[user_id].indices]

        scores = model.predict(user_id, np.arange(n_items))
        top_items = data['item_labels'][np.argsort(-scores)]

        # known_positives_more = data['train'].tocsr()[user_id].indices
        # top_items_more = data['item_feature_labels'][np.argsort(-scores)]

        # print("~" * 30)
        # print(known_positives_more)
        # print(top_items_more)
        # print("~" * 30)

        print("User %s" % user_id)
        print("     Known positives:")

        for x in known_positives[:3]:
            print("        %s" % x)

        print("     Recommended:")

        for x in top_items[:3]:
            print("        %s" % x)

        return {
            "top_3_liked_movies": known_positives[:3],
            "top_3_recommended_movies": top_items[:3]
        }


def get_recommendation(user_id):
    with open(MODEL_PATH, 'rb') as fid:
        model = pickle.load(fid)

        user_id = int(user_id)  # add try catch
        return sample_recommendation(model, data, [user_id])
