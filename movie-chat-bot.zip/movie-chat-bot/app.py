from flask import Flask, render_template, redirect, request as flask_request
import apiai
import json
import sys
import os
from movie_predictor import get_recommendation


APIAI_CLIENT_ACCESS_TOKEN = "e4bd5a505b4945e982ea4df6221ac51e"


app = Flask(__name__)

api_ai = apiai.ApiAI(APIAI_CLIENT_ACCESS_TOKEN)


@app.route("/")
def root():
    return render_template('index.html')


@app.route('/api_ai_test', methods=['POST'])
def apiAiTEst():

    requestData = flask_request.json

    if requestData["query"]:
        session_id = "1234567890"
        if requestData["session_id"]:
            session_id = str(requestData["session_id"])

        request = api_ai.text_request()
        request.session_id = session_id

        request.query = requestData["query"]

        response = request.getresponse()
        response = json.loads(response.read().decode('utf-8'))

        print(json.dumps(response, indent=2))

        print("~" * 30)
        print(response.get("result").get("parameters").get("number"))

        if response.get("result").get("parameters").get("number"):
            movies_recommendation_details = get_recommendation(response.get(
                "result").get("parameters").get("number"))

            print(movies_recommendation_details)

            returnData = {
                "status": True,
                "message": "Some issue occured",
                "top_3_liked_movies": list(movies_recommendation_details.get("top_3_liked_movies")),
                "top_3_recommended_movies": list(movies_recommendation_details.get("top_3_recommended_movies")),
                "session_refresh": True
            }
        else:
            responseValue = response.get("result").get(
                "fulfillment").get("speech")

            returnData = {
                "status": True,
                "message": responseValue
            }
    else:

        returnData = {
            "status": False,
            "message": ""
        }

    return json.dumps(returnData)


if __name__ == '__main__':
    app.debug = False
    app.run(host='0.0.0.0', port=9967)
